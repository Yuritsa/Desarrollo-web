# JS- colors change

A Pen created on CodePen.

Original URL: [https://codepen.io/INGRITH-YURITSA-PAEZPIDIACHE/pen/ByoMBaV](https://codepen.io/INGRITH-YURITSA-PAEZPIDIACHE/pen/ByoMBaV).

