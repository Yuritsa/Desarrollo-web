# Album JS

A Pen created on CodePen.

Original URL: [https://codepen.io/INGRITH-YURITSA-PAEZPIDIACHE/pen/azvMPMx](https://codepen.io/INGRITH-YURITSA-PAEZPIDIACHE/pen/azvMPMx).

